module.exports = {
    'secretKey': '123456-00-bnbnb',
    'mongoUrl': 'mongodb://localhost:27017/nucampsite'
}